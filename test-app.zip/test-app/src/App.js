import React, {Component} from 'react';
import axios from 'axios';
import './App.css';

const URL = '127.0.0.1:5000';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      message:[]
    };
  }
  
  componentDidMount(){
    // let message =[];
	axios.post(URL,[{"sentence":"i am in pregnancy"}])
    /*axios
       .get(URL)
      .then(res => {
        const message = res.data.title;
        console.log(message);
        this.setState({message});
      }) */
  }

  onSubmit(event){
    alert('form submitted');
  }
  render(){
    return(
      <div>
        <div>
          <form onSubmit={this.onSubmit}>
            <input  type="text" placeholder="Type here"/>
            <input type="submit" value="submit" className="input_box"/>
          </form>
        </div>
        <div class="blue_box">
        <span>{this.state.message}</span>
        </div>
        {/* <div class="green_box">
        <span>Bye</span>
        </div> */}
        
      </div>
    )
  }
  }



export default App;




// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }